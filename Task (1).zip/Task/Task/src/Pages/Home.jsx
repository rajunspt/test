import React from 'react'

const Home = () => {
  return (
    <>home page</>
  )
}

export default Home
