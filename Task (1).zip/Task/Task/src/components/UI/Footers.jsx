import React from 'react'

const Footers = () => {
  return (
    <h1>
        footers
    </h1>
  )
}

export default Footers
