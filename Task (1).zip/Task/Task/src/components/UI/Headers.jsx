import React from 'react'
import Navbar from '../UI/Navbar'

const Headers = () => {
  return (
     <Navbar/>
    
   
  )
}

export default Headers
