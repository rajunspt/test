module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Adjust paths based on your file structure
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
