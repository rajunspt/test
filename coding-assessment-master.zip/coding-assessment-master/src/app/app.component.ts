import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { map, defaultIfEmpty } from 'rxjs/operators';
import { TodosService } from '../app/todos/services/todos.service'
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { ITodo } from '../app/todos/interfaces/ITodo';
import * as todoSelectors from 'app/todos/state/todo.selectors';
import { filter } from 'minimatch';



@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {

  newTodoText = '';
  todoStore: TodosService;
  todosData: Observable<ITodo[]>;
  todosDataAll: Observable<ITodo[]>;
  currentFilter: string; 
  constructor(todoStore: TodosService, private store: Store<{ todos: ITodo[] }>) {
    this.todoStore = todoStore;
    this.currentFilter = "all"


  }

  // Add New todo
  addTodo() {
    if (this.newTodoText.trim().length) {
      this.todoStore.addTodo(this.newTodoText);
      this.newTodoText = '';
      this.todosData = this.store.pipe(select(todoSelectors.allTodos));
      this.todosDataAll = this.store.pipe(select(todoSelectors.allTodos));
    }
  }

  // Display all todos
  displayAll() {
    this.currentFilter = 'all';
    this.todosData = this.todosDataAll;
  }

  // Display Active todos
  displayRemaining() {
    this.currentFilter = 'remaining';
    this.todosData = this.todosDataAll
      .pipe(
        map(items => items.filter(item => !item.completed))
      );
  }


  // Display Completed todos
  displayCompleted() {
    this.currentFilter = "completed"
    this.todosData = this.todosDataAll
      .pipe(
        map(items => items.filter(item => item.completed))
      );     
  }

  




}
