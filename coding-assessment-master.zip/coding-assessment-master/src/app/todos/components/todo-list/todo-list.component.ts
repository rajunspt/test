import { Component,Input,Output,EventEmitter } from '@angular/core';
import { TodosService } from 'app/todos/services/todos.service';


@Component({
  selector: 'app-todos-list',
  styleUrls: [
    './todo-list.component.scss',
  ],
  templateUrl: './todo-list.component.html',
})
export class TodosListComponent {
  @Input() todosData : any;  
  constructor(private todoDataService: TodosService){  
  }

  toggleTodoComplete(index) {  
    this.todoDataService.toggleComplete(index);
  }
  removeTodo(index) {
    this.todoDataService.removeTodo(index);
  }
}
