export class ITodo {
  text: string;
  completed?: boolean;
}
